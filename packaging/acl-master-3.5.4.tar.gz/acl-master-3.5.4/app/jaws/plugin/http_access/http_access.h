#ifndef	__HTTP_ACCESS_INCLUDE_H__
#define	__HTTP_ACCESS_INCLUDE_H__

void http_access_init(void);
int http_access_permit(const char *domain);

#endif
