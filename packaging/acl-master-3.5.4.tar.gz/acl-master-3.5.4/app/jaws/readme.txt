Jaws(Just a webserver) can run on Unix/Windows
