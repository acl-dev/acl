//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by JawsCtrl.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_JAWSCTRL_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDR_MENU_ICON                   129
#define IDI_MIN_ICON                    130
#define IDC_EDIT_PORT                   1001
#define IDC_IPADDRESS_LISTEN            1002
#define IDC_BUTTON_START                1003
#define IDC_BUTTON_STOP                 1004
#define IDC_RADIO_HTTPD                 1005
#define IDC_RADIO_HTTP_PROXY            1006
#define IDC_BUTTON_QUIT                 1007
#define IDC_DIVIDER                     1009
#define IDC_MORE                        1010
#define IDC_DIVIDER_HOR                 1011
#define IDC__AUTO_RUN                   1013
#define IDC_AUTO_RUN                    1013
#define ID_OPEN_MAIN                    32773
#define ID_QUIT                         32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1014
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
