
#ifndef	__LOG_WRAP_INCLUDE_H__
#define	__LOG_WRAP_INCLUDE_H__

#ifdef __cplusplus
extern "C" {
#endif

extern void app_set_libcore_log(void);
extern void app_libcore_log_end(void);

#ifdef __cplusplus
}
#endif

#endif

