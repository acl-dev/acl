#!/bin/sh

./master_dispatch alone "./dispatch.sock;1080" master_dispatch.cf
