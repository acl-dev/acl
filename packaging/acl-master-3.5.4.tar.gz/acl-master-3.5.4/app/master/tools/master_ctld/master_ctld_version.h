#ifndef __MASTER_CTLD_VERSION_INCLUDE_H__
#define __MASTER_CTLD_VERSION_INCLUDE_H__

#define MASTER_CTLD_VERSION  "1.0.0-0"
#define MASTER_CTLD_DATE     "20180123"
#define MASTER_CTLD_CMD      "master_ctld"

#endif
