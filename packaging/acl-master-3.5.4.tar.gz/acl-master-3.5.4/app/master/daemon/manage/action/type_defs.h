#pragma once

#define	STATUS_TIMEOUT	503
