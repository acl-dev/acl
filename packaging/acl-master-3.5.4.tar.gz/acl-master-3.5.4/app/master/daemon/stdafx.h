#ifndef __STDAFX_INCLUDE_H_
#define __STDAFX_INCLUDE_H_

#include <vector>
#include <set>
#include <list>

#include "lib_acl.h"
#include "lib_protocol.h"
#include "acl_cpp/lib_acl.hpp"

#include "json/serialize.h"

#endif
