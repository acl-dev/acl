#ifndef __MASTER_VERSION_INCLUDE_H__
#define __MASTER_VERSION_INCLUDE_H__

#define MASTER_NAME	"acl_master"
#define MASTER_VERSION	"3.5.3-0"
#define MASTER_DATE	"20220601"

#endif
